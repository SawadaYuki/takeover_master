#error "You should include dmtcp.h file instead."
