This scipts was provided by L. Shawn Matott 
Center for Computational Research (CCR) University of Buffalo 
while deploying DMTCP on CCR rush cluster
(http://ccr.buffalo.edu/support/research_facilities/general_compute.html)
